makeInstancesUFO -d RomanMasters/SourceCodePro.designspace
makeInstancesUFO -d ItalicMasters/SourceCodePro-It.designspace
