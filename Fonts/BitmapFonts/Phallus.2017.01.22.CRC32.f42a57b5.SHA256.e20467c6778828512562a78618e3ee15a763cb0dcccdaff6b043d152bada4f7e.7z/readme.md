#Lemon

Personal mod of lime with better kerning, more distinguished characters, and powerline/icon support.


#uushi

My take on Monaco. Overall, it's much less curved than lemon but still retains many of the same features and ideas (e.g, readability, icons, etc).


#Installation

Install via the AUR, or run the install script provided.

#Note on icons/powerline

To enable powerline support, be sure to set powerline symbols to 'fancy'. To use the icons, enter vim's insert mode and hold ctrl-shift (assuming urxvt); while doing so, press the corresponding number of the desired icon. For convenience, both fonts use the same unicode position for the same characters. 

UPDATE: To make things easier on everyone, I added a file in which the icons are readily available for copying and pasting.
