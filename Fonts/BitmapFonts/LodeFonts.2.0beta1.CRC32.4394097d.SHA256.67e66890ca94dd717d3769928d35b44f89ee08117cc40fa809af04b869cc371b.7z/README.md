lode-fonts
==========

Custom fonts for GoboLinux, designed by [Hisham Muhammad](http://hisham.hm).

Run `make install` to install them.
