# Gohufont
Gohufont is a monospace bitmap font, available in 11-px and 14-px heights.

### Website

For more information and screenshots, please take a look at the website [font.gohu.org](http://font.gohu.org)

### License

Copyright 2015 by Hugo Chargois

This font is released under the terms of the [WTFPL version 2](http://www.wtfpl.net/about/) (see COPYING-LICENSE).

### Thanks and acknowledgments

 * The Unicode versions of the 11-px font are based extensively on the fixed 6x10 font by Markus Kuhn (http://www.cl.cam.ac.uk/~mgk25/ucs-fonts.html).
 * I used the Terminus font in 14 px with great satisfaction for a long time before I decided to make gohufont 14 px, so it surely inspired me and they may share some similarities in appearance. It is not a derivative work though. Thanks to Dimitar Zhekov for his great font.
