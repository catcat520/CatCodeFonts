Gohufont TrueType
====================

A font for programming and terminal use.

TrueType automatically traced, with available bitmaps in heights of 11 and 14 pixels.

Copyright 2010 by Hugo Chargois (http://font.gohu.eu)

Converted by Guilherme Maeda (github.com/koemaeda)

<b>LICENSE</b>
This font is released under the terms of the WTFPL (see COPYING-LICENSE).

<b>THANKS AND AKNOWLEDGMENTS</b>
The Unicode versions of the 11px font are based extensively on the fixed 6x10 font by Markus Kuhn (http://www.cl.cam.ac.uk/~mgk25/ucs-fonts.html).
I used the Terminus font in 14 px with great satisfaction for a long time before I decided to make gohufont 14 px, so it surely inspired me and they may share some similarities in appearance. It is not a derivative work though. Thanks to Dimitar Zhekov for his great font.
