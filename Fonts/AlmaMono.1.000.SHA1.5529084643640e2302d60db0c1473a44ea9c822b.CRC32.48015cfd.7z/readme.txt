ALMA MONO - THE TYPEFACE

Hi there!
Thank you for the purchase - I hope you will enjoy this typeface! As you know all the proceeds go towards a good thing. Thank you so much for the support!

The license document has more legal information but I'd like to break it down as simply as possible here.

*** This you CAN do with this typeface if you bought a personal license: 
Design something awesome and get paid for it. Create logos and brands for yourself or clients with this font.

Use it on one(1) personal website - webfonts are included. Just get cracking! 

*** This you CAN do with this typeface if you bought a commercial use license: 
As everything above in the personal license but now you can also distribute to employees in your company and install it to computers in your company. For instance: If you would like coders in your company to use it in their editor of choice. All I ask is that you only install it on as many devices as the license you bought.

Would you like to use it on a corporate website or commercial website? Contact me! 

*** This you CAN’T do with this:
Sell it and/or redistribute it. That's it.

If you have any problem and/or suggestion for further development of this typeface feel free to email me: daniel@feldt.nu.

Signup for future updates of the font and news about upcoming fonts here:
http://eepurl.com/bjq0U5

Oh, and if you use the font anywhere I'd be super excited for a link where it's in use or a pic. Tweet me (@dafeld) or instagram a pic (tag @dafeld) or email me.

Thanks again and take care,
Daniel Feldt
