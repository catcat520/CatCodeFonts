Use these for blogs etc...

![image](https://github.com/andreaslarsen/monoid/raw/master/Utilities/Images/MonoidReadme.png)
<p>&nbsp;</p>
![image](https://github.com/andreaslarsen/monoid/raw/master/Utilities/Images/Monoisome.png)
<p>&nbsp;</p>
![image](https://github.com/andreaslarsen/monoid/raw/master/Utilities/Images/Monoid1.png)
<p>&nbsp;</p>
![image](https://github.com/andreaslarsen/monoid/raw/master/Utilities/Images/Monoid2.png)
<p>&nbsp;</p>
![image](https://github.com/andreaslarsen/monoid/raw/master/Utilities/Images/Monoid3.png)
<p>&nbsp;</p>
![image](https://github.com/andreaslarsen/monoid/raw/master/Utilities/Images/Monoid4.png)
