sudo-font
=========

Sudo is a monospaced font designed for terminal and programming. Use at 16 pixels size for optimal results.

Download the fonts at https://www.kutilek.de/sudo-font/.

<img src="https://raw.github.com/jenskutilek/sudo-font/master/images/sudo-textmate-py.png">

Sudo in TextMate
