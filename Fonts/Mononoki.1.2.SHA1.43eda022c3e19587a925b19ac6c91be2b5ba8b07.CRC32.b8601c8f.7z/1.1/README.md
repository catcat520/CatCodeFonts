#mononoki
####a font for programming and code review

for a closer look [http://madmalik.github.io/mononoki/](http://madmalik.github.io/mononoki/)

##installation
[download mononoki.zip](export/mononoki.zip) and unpack it
* [OS X](http://support.apple.com/kb/HT2509)
* [Windows](http://windows.microsoft.com/en-us/windows-vista/install-or-uninstall-fonts)
* Linux/Unix - distro dependent, i hope you know how to install it

##old version
if you prefer the predecessor to mononoki, please look into the branch monoOne
