Sheldon is a small bitmap font which is absolutely
great for programming.

It was made by Sheldon Simms, but he allowed me to distribute it.
It is absolutely free.

sheldon.fon is an old version, sheldon4.fon is the current version.
There are some differences, but I think you'll see that...

This distribution is provided in the hope that it will be useful.
However, it is provided AS IS and carries NO WARRANTY that it will
do anything good and NO WARRANTY that it will not do anything bad.
Your use of the fonts and software that make up this distribution
is ENTIRELY AT YOUR OWN RISK.
Sheldon Simms and Tobias Jung hereby disclaim any and all liability
for any difficulty you may have as a result of using any part of
this distribution.  If these terms are not acceptable to you,
then you must not use any part of this distribution.

For any questions or comments about this distribution, contact
profont@tobiasjung.name


Tobias Jung
August 2002