Here is a version of ProFont for Windows, TrueType,
containing polish characters.
(work with MacOS X as well)


DISCLAIMER

See LICENSE file


To get the full original Distribution, other ProFont builds
and more information
go to <http://tobiasjung.name/profont/>


Tobias Jung
January 2014
